import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * @author Manik, Neha
 *
 * ProcessClientRequest includes the implementation of 
 * execution and processing of the shell command 
 * on Linux operating system and also creation of multiple threads 
 * to initiate connection of Server to other Remote Servers 
 * in case the message received is not from a local host
 */

public class ProcessClientRequest {
	
	private Socket          socket   = null;
	private ServerSocket    server   = null;
	String logResult;
	
	public ProcessClientRequest(Socket socket, ServerSocket server){
		this.socket = socket;
		this.server = server;
	}
	
	/* ** The method processInput() performs the following tasks
	 * 1. Reads the message entered by the user
	 * 2. Executes the shell command by making a call to executeShellCommand function
	 * 3. Checks to see of Executor Worker threads needs to be created in case the message is received from remote Server
	 * 4. Repeats the above steps until Over message is received from the user
	 ** */
	
	public void processInput() throws IOException, InterruptedException {
		System.out.println("Reading input from the user");
		
		//sets up input and output stream from the socket
		DataInputStream in = new DataInputStream(new BufferedInputStream
													(socket.getInputStream())); 
		DataOutputStream out = new DataOutputStream((new BufferedOutputStream
														(socket.getOutputStream())));
		
		String clientInput =""; //variable to store the shell command entered by the user
		System.out.println("socket.getInetAddress(): "+socket.getInetAddress());
		
	    //reads message from client until "Over" is received
		while (!clientInput.equals("Over") )
	    {
			clientInput ="";
			try
	        {	
        			System.out.println("Reading from the input stream");
        			clientInput = in.readUTF(); // takes input from the client socket
        			System.out.println("Writing what was delivered to the server::" +clientInput);
        			String hostServer = socket.getInetAddress().toString();
        			System.out.println("ClientAddress" +hostServer);
	            
	        		
	        		if(clientInput != null )
		        	{
	        			//check to ensure that the threads are created only when the request is not received from the local client
	        			if(hostServer.contains(socket.getLocalAddress().toString())){
	        				createServerThread(clientInput);
	        			}
	   
	        			//check to ensure that the Client input is not empty and not Over
	        			if(clientInput != null && !clientInput.equals("Over")){
	        				logResult = executeShellCommand(clientInput);//execute shell command via Runtime and Process
	        				System.out.println("Log Result::"+ logResult);
	        				out.writeUTF(logResult);
	        				System.out.println("Response sent to client after command execution.....");
	        				out.flush();
	        			}
				
	        			//check to ensure that Remote Server connection is closed post the command execution until further request is received
	        			if(!socket.getInetAddress().toString().contains(socket.getLocalAddress().toString())){
	        				System.out.println("Starting a  new socket for the remote machine only");
					
	        				in.close();
	        				out.close();	
	        				socket.close(); 
	 				
	        				if(!clientInput.equals("Over")){
	        					socket = server.accept(); // waits for a new request to be send by the User
	        					in = new DataInputStream(
	        							new BufferedInputStream(socket.getInputStream()));
	        					out = new DataOutputStream((new BufferedOutputStream
	        							(socket.getOutputStream())));
	        	 		
	        				}else{
	        					break; //to force exit the while loop if Over message is received
	        				}//end of inner else - if 
	        			}
				}//end of outer if
	        }catch(IOException i)
	        {
	            i.printStackTrace();
	        } //end of try catch block
			
	    } //end of while loop
		
		System.out.println("User Request has been processed, End of process Input");
		in.close();
		out.close();
		
	}//end of processInput() function
	
	/* The method createServerThread() creates threads to communicate with the Remote Server. In case 
	 * remote server is not up or connection is failed, the corresponding thread is killed and code proceeds 
	 * with the remaining server execution*/
	public void createServerThread(String inputcmd) throws UnknownHostException, InterruptedException{            
        String[] hostNames = {"ec2-52-39-68-190.us-west-2.compute.amazonaws.com", 
							  "ec2-34-216-142-102.us-west-2.compute.amazonaws.com",
							  "ec2-34-216-248-135.us-west-2.compute.amazonaws.com",
							  "ec2-54-201-10-149.us-west-2.compute.amazonaws.com"
							 }; //initialization of remote server public dns
        
        System.out.println("Starting the thread pool");
        ExecutorService executor = Executors.newFixedThreadPool(4);
        
        //passing the sockets to the runnable to start the session as required and also send the data to it
        for(int j =0 ; j < hostNames.length; j++) {
			System.out.println("Starting thread for host " + hostNames[j]);
			Runnable worker = new ServerThread(inputcmd, hostNames[j]);
			executor.execute(worker);
		}
    	executor.shutdown(); 
    	executor.awaitTermination(5000, TimeUnit.MILLISECONDS);
        	
        System.out.println("Ending the program");
    			           			            
    }//end of createServerThread() function
	
	/* The method executeShellCommand() executes the shell command via Runtime and process*/
	public String executeShellCommand(String line) throws IOException, InterruptedException{
		String []commands = {"/bin/sh", "-c" , line};
		Runtime rt = Runtime.getRuntime(); 
        Process proc = rt.exec(commands);
		proc.waitFor();//will wait for the process to complete the shell command execution 
        String x = "";
        
		StringBuilder result = new StringBuilder(); 
		
		result.append(socket.getLocalAddress().toString()).append("\n"); //to help differentiate the logs from different Remote Servers
        BufferedReader inStreamReader = new BufferedReader(new InputStreamReader(proc.getInputStream()));
        
        while( (x = inStreamReader.readLine()) != null){
        		result.append(x);
        }//end of while loop
        
        System.out.println("writing result of shell command to the client....");
        return result.toString();
        
   	}//end of executeShellCommand() function
	
}

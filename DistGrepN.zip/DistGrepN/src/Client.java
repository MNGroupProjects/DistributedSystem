import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * @author Manik, Neha
 *
 * Client program to read Shell Command from the User
 * and connect to the Server in order to fetch the results from Linux Server
 *
 */

public class Client {
	
		//initialize socket and input stream
		private Socket socket = null;
		private DataInputStream input = null;
		private DataInputStream in = null;
		private DataOutputStream output = null;
		File cmdFile;
		private String ServerResponse;
		
		//Client constructor to set the local host address and server port number for connection via socket
		public Client(String address, int port) throws IOException, InterruptedException {//establish a connection
			
			try {
				socket = new Socket("localHost", port);
				System.out.println("Connected");
				
				//take input from the terminal
				input = new DataInputStream(System.in);
				
				//take input from the socket 
				in = new DataInputStream(new BufferedInputStream
						(socket.getInputStream()));
				
				//send output to the socket
				output = new DataOutputStream(socket.getOutputStream());
				
			}catch(IOException e) {
				System.out.println(e);	
			}
		}//end of Client Constructor
		
		/* ** The method sendUserInput() performs the following tasks
		 * 1. Receives message from the user
		 * 2. Sends data to the Server for executing the shell command
		 * 3. Receives the response from the Server
		 * 4. Calls the LogMergeFile function to prepare the final Log result file
		 ** */
		private void sendUserInput() throws IOException {
			
			String userInput = ""; //string to read message from the input
			BufferedReader br
	          = new BufferedReader(new InputStreamReader(input));
			long startTime = System.currentTimeMillis();
			
			
			//read until Over is entered by the User
			while(!userInput.equals("Over")){
				try {
					System.out.println("Enter a shell command to continue::");
					userInput = br.readLine();
					output.writeUTF(userInput);
				}catch (IOException e) {
					e.printStackTrace();
				}
				System.out.println("Waiting for response from the server::");
				if(!userInput.contains("Over")){
					
					System.out.println("Command" + userInput + "result::");
					System.out.println(ServerResponse);
				}
			}//end of while loop
			long endTime = System.currentTimeMillis();
			try {
				LogFileMerger(); //call to the LogFileMerger function to create the final result file
			}catch (IOException e) {
				e.printStackTrace();
			}//end of this try catch block
			
	        try
	        {
	        	in.close();
	        	input.close();
	            output.close();
	            socket.close(); // close the connection 
	        }catch(IOException i) {
	        	System.out.println(i);
	        }//end of this try catch block
	        
	        System.out.println("Total time for Query execution in seconds::"+(endTime-startTime)/3600);
		}//end of sendUserInput Function
			
		/* ** The method LogFileMerger()() performs the following tasks
		 * 1. Creates a 'Results' file to write the final log result from all servers
		 * 2. First, writes the Server Response as received on the socket
		 * 3. Second, reads and appends the data from log files received from Remote Servers
		 * 4. Deletes the temporary files created to store the log from the Remote Server
		 * 5. File can be viewed via vim 'Results.tmp' from the command line
		 ** */
		public void LogFileMerger()throws IOException{
		
            //Writing results for local shell command as received in ServerResponse server from the Server
            File file = new File("Results.tmp");
            FileWriter writer = new FileWriter(file.getCanonicalPath());
            PrintWriter pw = new PrintWriter(writer);
            pw.print(ServerResponse);
            pw.print("\n");
			
			//Getting address of all other servers in network to check their output files
			//If it exists merging the data form temp files to the above mentioned Results.tmp file
            ArrayList<String> network = new ArrayList<String>
            	    (Arrays.asList("172313064", "1723123214","172312090","1723125244"));
			File tempFile;
			StringBuilder result = new StringBuilder();
			for(int i=0; i< network.size(); i++){
				if((tempFile = new File("Machine_"+ network.get(i)+"_log"+".tmp")).exists()){
					System.out.println("temp file found::" + tempFile.getName());
					BufferedReader br = new BufferedReader(new FileReader(tempFile));
					String x ="";
					while((x = br.readLine()) != null){
						result.append(x);
					}
					pw.print(result);
					br.close();
					tempFile.delete(); //deleting temp files from client machine to reduce overhead
					
				}else{
					System.out.println("No File Found : " + network.get(i));
				}//end of if - else 
				
			}//end of for loop
			pw.close();
			writer.close();
		}//End of LogFileMerge function
		
		public static void main(String args[]) throws IOException, InterruptedException
	    {
	        Client client = new Client("localHost",8000); 
	        client.sendUserInput();
	    }//End of main function
		
		public String getServerAddress(){
			String serverAddress = socket.getInetAddress().toString();
			return serverAddress;
		}
	
}

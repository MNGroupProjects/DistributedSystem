
import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
;

/**
 * @author Manik, Neha
 *
 * Server program to process the Input from the user and
 * run the command on Remote Servers. This server creates an 
 * Executor pool of workable threads in order to create a different 
 * instance of each remote Server
 * The detailed execution for running the shell command and thread module has been added 
 * in the ProcessClientRequest class
 */

public class Server {
		//initialize socket and input stream
		private Socket          socket   = null;//A plain old Socket socket to use for communication with the client.
		private ServerSocket    server   = null;//waits for the client requests (when a client makes a new Socket())
		
		public File cmdFile;
		String logResult;
		
		//constructor with port
		public Server(int port)
		{
		    try
		    {
		        server = new ServerSocket(port); // starts server and waits for a connection
		        System.out.println("Server started");
		        
		        System.out.println("Waiting for a client ...");
		        
	            socket = server.accept();
	            System.out.println("Client accepted");
	            
		    }catch(IOException i)
	        {
	            System.out.println(i);
	        }
		}//end of Server Constructor
		
		public void readUserInput(){
			ProcessClientRequest pcr = new ProcessClientRequest(socket, server);
			try {
				pcr.processInput();
				closeSocket();
			} catch (IOException | InterruptedException e) {
				e.printStackTrace();
			}
		}//end of readInput function
      
        public void closeSocket() throws IOException, InterruptedException {
		    
		    socket.close();	//close connection
		    server.close(); //close the server port
	    }//end the closeSocket function
        
		public static void main(String args[]) throws IOException, InterruptedException
	    {
			System.out.println("Starting the server");
	        Server server = new Server(8000);
	        server.readUserInput();
	        System.out.println("Ending the program");
	           
	    }//end of main function	
}

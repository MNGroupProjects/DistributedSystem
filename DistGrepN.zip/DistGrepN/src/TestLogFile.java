import static org.junit.Assert.assertEquals;

import org.junit.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;
public class TestLogFile {

	@Test
	public void ValidateResultLogFile() throws IOException, InterruptedException
    {
		File actual = new File(System.getProperty("user.dir")+"\\Results.tmp");
		File expected = new File(System.getProperty("user.dir")+"\\ExpectedResult.tmp");
	
	    int i = 0;
	    int step = 4096;
	    boolean equal = false;
	
	    FileInputStream fi1 = new FileInputStream(actual);      
	    FileInputStream fi2 = new FileInputStream(expected);
	
	    byte[] fi1Content = new byte[step];
	    byte[] fi2Content = new byte[step];
	    boolean equalContent = true;;
	
	    if(actual.length() == expected.length()) { 
	    while(i*step < actual.length()) {   
	
	        fi1.read(fi1Content, 0, step); 
	        fi2.read(fi2Content, 0, step); 
	
	        equalContent = Arrays.equals(fi1Content, fi2Content); 
	
	        if(!equalContent) { //Assumption 3
	            break;
	        }
	        ++i;
	    }
	}
	fi1.close();
	fi2.close();
	System.out.println(equalContent);
		
    }
}

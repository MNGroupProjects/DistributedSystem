import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * @author Manik, Neha
 *
 * ServerThread executes the run method to connect to the 
 * Remote Servers, send the command to be executed, receives the response 
 * from the Remote Servers and writes it to a temporary log file
 */

public class ServerThread implements Runnable {

	private String cmd = null;
	private String host = null;
	int port = 8000;
	
	DataOutputStream output= null ;
	String address;
	Socket socket;
	
	public ServerThread(String cmd, String host) throws UnknownHostException {
		
		this.cmd = cmd;
		this.host = host;
		address = InetAddress.getByName(host).toString();
	}//end of constructor
	
	
	/* ** The method createSessionWithRemoteServer() performs the following tasks
	 * 1. Connects to the remote servers
	 * 2. Receives the response for the shell command execution
	 * 3. Call to the CreateLogFile function
	 * 4. Closes the socket with the Remote Server once the process is completed
	 ** */
	public void createSessionWithRemoteServer(String shellcmd) throws IOException{
		System.out.println("Creating session");
		boolean connRefused = false;
		try{
			socket = new Socket(host, port);
			System.out.println("Connected to : " + host + " with name : ");
		
			System.out.println("Message sent to the server : "+shellcmd);
			output = new DataOutputStream(socket.getOutputStream()); 
		
		}catch(IOException e){
			connRefused = true;
			System.out.println("Connection cannot be established with the server " + host);
		}
		if(!connRefused){
	        try
	        {
	        	output.writeUTF(shellcmd);//Send the message to the Remote Server
				if(!shellcmd.contains("Over")){
					CreateLogFile(); //call to the function to create log file for result received from the Remote Server
				}
				Thread.sleep(2*1000);
	        	
	        	System.out.println("reached inside ending try block in Server Thread class.....");
	        }catch(IOException | InterruptedException e){
	        	e.printStackTrace();
	        }finally{
        		socket.close(); // close the connection
        		output.close();
	        }
		}
        System.out.println("Socket Closed, check if thread ended");
	}//end of createSessionWithRemoteServer function

	@Override
	public void run() {
		System.out.println("Entering the thread");
		try {
			createSessionWithRemoteServer(cmd);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	//creating log file at the server
	public void CreateLogFile() throws IOException{
		DataInputStream inStreamReader = new DataInputStream(new BufferedInputStream
				(socket.getInputStream()));
		System.out.println("Creating log file in server thread::");
		String remoteServer = socket.getInetAddress().getHostAddress();
		
		String remoteAddress = remoteServer.replace("/", "").replace(".", "");
		System.out.println("Updated Address of Remote Server for File:: "+remoteAddress);
		StringBuilder result = new StringBuilder();
		result.append(socket.getLocalAddress().toString()).append("\n");
		String x = "";
     
        while( (x = inStreamReader.readLine()) != null){
        	System.out.println("Writing the result from RM : " + x);
    		result.append(x);
        }
        
		File file = new File("Machine_"+ remoteAddress + "_log"+".tmp");		
		FileWriter writer = new FileWriter(file.getCanonicalPath());
        PrintWriter pw = new PrintWriter(writer);
		System.out.println("File Path::"+file.getCanonicalPath());
        
		inStreamReader.close();
        System.out.println("Response saved to the file is::" + result.toString());
        pw.print(result.toString()); //write the result to the file
        pw.close();
        
        System.out.println("Exiting log creation at server thread");
	}// end of CreateLogFile function

}

import static org.junit.Assert.*;

import java.io.IOException;
import java.net.ConnectException;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class ConnectionTestClass {

	@Rule
	public final ExpectedException exception = ExpectedException.none();
	
	@Test
    public void testValidIPAndPort() throws IOException, InterruptedException
    {
		Client client = new Client("localHost", 8000);
		boolean expected = true;
		boolean actual = false;
		String ServerAddress = client.getServerAddress();
		if ( !ServerAddress.isEmpty())
			actual = true;
		String successMessage = "Client is successfully connected to the Server";
		assertEquals(successMessage, expected, actual);
    }
	
	@Test
	public void testInvalidIPAndPort() {
		try{
			Client client = new Client("localHost", 5000);
			System.out.println("Code should not have reached here:");
		}catch(IOException | InterruptedException e){
			exception.expect(ConnectException.class);
			System.out.println("Connection to Server Timed Out");
		}
	}
	
}

